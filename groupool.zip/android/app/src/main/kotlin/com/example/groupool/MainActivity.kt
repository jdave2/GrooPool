package com.example.groupool

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
